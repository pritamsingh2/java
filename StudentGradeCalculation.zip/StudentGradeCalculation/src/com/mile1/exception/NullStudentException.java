package com.mile1.exception;

public class NullStudentException extends Exception {

public String toString()  {
	
	return "NullStudentException occurred" ;
}

}
